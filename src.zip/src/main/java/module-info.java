/**
 * 
 */
/**
 * 
 */
module LabTest2 {
    requires java.sql;
    requires jakarta.servlet;
}